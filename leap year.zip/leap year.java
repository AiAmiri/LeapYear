import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		System.out.println("calculator for leap year");
		System.out.println("");
		System.out.println("enter a year");
		Scanner leap = new Scanner(System.in);
		int x = leap.nextInt();
		if  (x%4==0 && x%100!=0) {
		  // if (x%400==0)
		  System.out.println("it is a leap year");
		}
		else {
		    System.out.println("It is not a leap year");
		}
	}
}